import React from "react";
const Footer=()=>{
    return (
        <div className="text-center">
            <h6>Designed by XYZ Company</h6>
        </div>
    )
}
export default Footer;
