package com.MovieApps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieAppsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieAppsApplication.class, args);
	}
}
